
import React from "react";
import Scheduler from "@/components/Scheduler";

const Index: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-4">
      <Scheduler />
    </div>
  );
};

export default Index;
